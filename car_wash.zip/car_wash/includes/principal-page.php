<div class="container-fluid">
<h1 class="mt-4">Bienvenido</h1>
    <p>Car Wash</p>
</div>